<?php
$adminDataDir = __DIR__ . '/admin/data';

$content = [];
$seo = [];
$blogPosts = [];
$companyName = 'HSYNC Group';
$companyWebsite = 'https://hsync.xyz';
$companyEmail = 'info@hsync.xyz';
$companyAddress = 'Los Angeles, California, USA';

// load company info from config if exists
$configPath = __DIR__ . '/admin/config.php';
if (file_exists($configPath)) {
    require $configPath;
    if (!empty($COMPANY_NAME)) $companyName = $COMPANY_NAME;
    if (!empty($COMPANY_WEBSITE)) $companyWebsite = $COMPANY_WEBSITE;
    if (!empty($COMPANY_EMAIL)) $companyEmail = $COMPANY_EMAIL;
    if (!empty($COMPANY_ADDRESS)) $companyAddress = $COMPANY_ADDRESS;
}

// load content
if (file_exists($adminDataDir . '/site-content.json')) {
    $contentJson = file_get_contents($adminDataDir . '/site-content.json');
    $content = json_decode($contentJson, true) ?: [];
}

// load seo
if (file_exists($adminDataDir . '/seo.json')) {
    $seoJson = file_get_contents($adminDataDir . '/seo.json');
    $seo = json_decode($seoJson, true) ?: [];
}

// load blog posts
if (file_exists($adminDataDir . '/blog-posts.json')) {
    $postsJson = file_get_contents($adminDataDir . '/blog-posts.json');
    $blogPosts = json_decode($postsJson, true) ?: [];
}

// helpers
$homeTitle = $seo['home']['title'] ?? "$companyName - Company site";
$homeDesc = $seo['home']['description'] ?? '';

$homeHeading = $content['home_heading'] ?? "$companyName digital venture studio";
$homeSubtitle = $content['home_subtitle'] ?? 'We create and operate modern brands in ecommerce, services and technology.';
$aboutText = $content['about_text'] ?? '';
$servicesText = $content['services_text'] ?? '';
$contactText = $content['contact_text'] ?? '';

$latestPosts = array_reverse($blogPosts);
$latestPosts = array_slice($latestPosts, 0, 3);

// simple manual brand list for now
$brands = [
    ['name' => 'SmokeMEGA', 'type' => 'Ecommerce', 'note' => 'Smoking accessories and lifestyle'],
    ['name' => 'ReputationSupports', 'type' => 'Services', 'note' => 'SEO, web and digital growth'],
    ['name' => 'AWorkCafe', 'type' => 'Platform', 'note' => 'Global freelance marketplace'],
    ['name' => 'ThePinkAndBlue', 'type' => 'Ecommerce', 'note' => 'Fashion and lifestyle brand'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($homeTitle) ?></title>
    <meta name="description" content="<?= htmlspecialchars($homeDesc) ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<div class="page-shell">
    <header class="header">
        <div class="header-inner">
            <div class="logo-wrap">
                <div class="logo-mark">HS</div>
                <div>
                    <div class="logo-text-main"><?= htmlspecialchars($companyName) ?></div>
                    <div class="logo-text-sub">Multi brand digital venture studio</div>
                </div>
            </div>
            <nav class="nav">
                <a href="#home">Overview</a>
                <a href="#brands">Brands</a>
                <a href="#services">Services</a>
                <a href="#insights">Insights</a>
                <a href="#contact">Contact</a>
                <a href="/admin/login.php">Admin</a>
            </nav>
        </div>
    </header>

    <main class="main">
        <!-- Hero -->
        <section id="home" class="hero">
            <div>
                <div class="hero-highlight">
                    <span class="hero-highlight-dot"></span>
                    <span>Operating ventures in ecommerce, SaaS and services</span>
                </div>
                <h1 class="hero-title"><?= htmlspecialchars($homeHeading) ?></h1>
                <p class="hero-subtitle"><?= nl2br(htmlspecialchars($homeSubtitle)) ?></p>

                <div class="hero-meta">
                    <span class="hero-pill">Parent: <?= htmlspecialchars($companyName) ?></span>
                    <span class="hero-pill">Brands: <?= count($brands) ?> active</span>
                    <span class="hero-pill">HQ: Los Angeles</span>
                </div>
            </div>

            <div class="hero-right">
                <div class="hero-card">
                    <div class="hero-card-label">Core focus</div>
                    <div class="hero-card-main">Digital brands with shared tech stack</div>
                    <div class="hero-card-sub">One central ERP, CRM and analytics layer that supports all your ventures.</div>
                </div>
                <div class="hero-card">
                    <div class="hero-card-label">What HSYNC does</div>
                    <div class="hero-card-main">Build, test and scale</div>
                    <div class="hero-card-sub">From idea and product to operations, marketing and long term optimization.</div>
                </div>
            </div>
        </section>

        <!-- About -->
        <section id="about" class="section">
            <div class="section-header">
                <h2 class="section-title">About <?= htmlspecialchars($companyName) ?></h2>
                <div class="section-kicker">Foundation and direction</div>
            </div>
            <p><?= nl2br(htmlspecialchars($aboutText)) ?></p>

            <div class="card-grid" style="margin-top:12px;">
                <div class="card">
                    <div class="card-label">What we operate</div>
                    <div class="card-value">Multi brand portfolio</div>
                    <div class="card-sub">Ecommerce, marketplaces, consulting and future SaaS products.</div>
                </div>
                <div class="card">
                    <div class="card-label">How we think</div>
                    <div class="card-value">Systems first</div>
                    <div class="card-sub">Shared design, shared data and central tooling for all brands.</div>
                </div>
                <div class="card">
                    <div class="card-label">Where we work</div>
                    <div class="card-value">Remote first</div>
                    <div class="card-sub">Distributed team with central coordination through HSYNC OS.</div>
                </div>
            </div>
        </section>

        <!-- Brands -->
        <section id="brands" class="section">
            <div class="section-header">
                <h2 class="section-title">Brands under HSYNC</h2>
                <div class="section-kicker">Each brand, one shared backbone</div>
            </div>
            <p>HSYNC is the parent company behind several brands. Each brand runs with its own audience and positioning while sharing technology and operational playbooks.</p>

            <div class="card-grid" style="margin-top:12px;">
                <?php foreach ($brands as $brand): ?>
                    <div class="card">
                        <div class="card-label"><?= htmlspecialchars($brand['type']) ?> brand</div>
                        <div class="card-value"><?= htmlspecialchars($brand['name']) ?></div>
                        <div class="card-sub"><?= htmlspecialchars($brand['note']) ?></div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="chip-row">
                <span class="chip chip-pill">Ecommerce</span>
                <span class="chip">Service businesses</span>
                <span class="chip">Marketplaces</span>
                <span class="chip">Automation</span>
            </div>
        </section>

        <!-- Services -->
        <section id="services" class="section">
            <div class="section-header">
                <h2 class="section-title">What we build and manage</h2>
                <div class="section-kicker">From idea to operations</div>
            </div>
            <p><?= nl2br(htmlspecialchars($servicesText)) ?></p>

            <div class="card-grid" style="margin-top:12px;">
                <div class="card">
                    <div class="card-label">Brand creation</div>
                    <div class="card-value">Concept to live store</div>
                    <div class="card-sub">Naming, positioning, UX and full ecommerce setup across multiple markets.</div>
                </div>
                <div class="card">
                    <div class="card-label">Technology</div>
                    <div class="card-value">Custom ERP and CRM</div>
                    <div class="card-sub">Internal HSYNC OS layer for projects, team, time, analytics and automation.</div>
                </div>
                <div class="card">
                    <div class="card-label">Growth</div>
                    <div class="card-value">SEO and performance</div>
                    <div class="card-sub">Content, technical SEO and performance marketing tailored for each brand.</div>
                </div>
            </div>
        </section>

        <!-- Insights / blog -->
        <section id="insights" class="section">
            <div class="section-header">
                <h2 class="section-title">Insights and updates</h2>
                <div class="section-kicker">From the HSYNC operating notebook</div>
            </div>

            <?php if (empty($latestPosts)): ?>
                <p>No public posts yet. Internal notes live inside the HSYNC OS.</p>
            <?php else: ?>
                <?php foreach ($latestPosts as $post): ?>
                    <article class="blog-list-item">
                        <div class="blog-title"><?= htmlspecialchars($post['title']) ?></div>
                        <div class="blog-meta"><?= htmlspecialchars($post['date'] ?? '') ?></div>
                    </article>
                <?php endforeach; ?>
                <p style="margin-top:10px;font-size:13px;">
                    <a href="/blog.php">View full blog</a>
                </p>
            <?php endif; ?>
        </section>

        <!-- Contact -->
        <section id="contact" class="section">
            <div class="section-header">
                <h2 class="section-title">Contact and partnerships</h2>
                <div class="section-kicker">Build with HSYNC</div>
            </div>
            <p><?= nl2br(htmlspecialchars($contactText)) ?></p>

            <div class="contact-rows">
                <div>Website:
                    <a href="<?= htmlspecialchars($companyWebsite) ?>" target="_blank">
                        <?= htmlspecialchars($companyWebsite) ?>
                    </a>
                </div>
                <div>Email:
                    <a href="mailto:<?= htmlspecialchars($companyEmail) ?>">
                        <?= htmlspecialchars($companyEmail) ?>
                    </a>
                </div>
                <div>Address: <?= htmlspecialchars($companyAddress) ?></div>
            </div>
        </section>
    </main>

    <footer class="footer">
        © <?= date('Y') ?> <?= htmlspecialchars($companyName) ?>. All rights reserved.
    </footer>
</div>
</body>
</html>
