<?php
session_start();

$employeesFile = __DIR__ . '/../admin/data/employees.json';
$employees = [];

if (file_exists($employeesFile)) {
    $json = file_get_contents($employeesFile);
    $employees = json_decode($json, true) ?: [];
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    $found = null;
    foreach ($employees as $emp) {
        if ($emp['email'] === $email && $emp['password'] === $password) {
            $found = $emp;
            break;
        }
    }

    if ($found) {
        $_SESSION['employee_logged'] = true;
        $_SESSION['employee_id'] = $found['id'];
        $_SESSION['employee_name'] = $found['name'];
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Wrong email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee login - HSYNC</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<div class="main" style="max-width:400px;margin:40px auto;">
    <section class="section">
        <h2>Employee login</h2>
        <p style="font-size:13px;color:#9ca3af;">For HSYNC team members.</p>

        <?php if ($error): ?>
            <p style="font-size:12px;color:#fecaca;"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <form method="post">
            <div class="form-field">
                <label for="email">Email</label>
                <input id="email" type="email" name="email" required>
            </div>
            <div class="form-field">
                <label for="password">Password</label>
                <input id="password" type="password" name="password" required>
            </div>
            <button class="button" type="submit">Sign in</button>
        </form>
    </section>
</div>
</body>
</html>
