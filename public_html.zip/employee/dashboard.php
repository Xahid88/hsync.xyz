<?php
session_start();
if (empty($_SESSION['employee_logged']) || $_SESSION['employee_logged'] !== true) {
    header('Location: login.php');
    exit;
}

$employeeId = $_SESSION['employee_id'];
$employeeName = $_SESSION['employee_name'];

$timeFile = __DIR__ . '/../admin/data/time-logs.json';
$logs = [];

if (file_exists($timeFile)) {
    $json = file_get_contents($timeFile);
    $logs = json_decode($json, true) ?: [];
}

$message = '';

// handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $now = date('Y-m-d H:i:s');
    $today = date('Y-m-d');

    if ($action === 'start') {
        $logs[] = [
            'employee_id' => $employeeId,
            'date' => $today,
            'start' => $now,
            'end' => null
        ];
        $message = 'Work started at ' . $now;
    } elseif ($action === 'end') {
        for ($i = count($logs) - 1; $i >= 0; $i--) {
            if ($logs[$i]['employee_id'] == $employeeId && $logs[$i]['end'] === null) {
                $logs[$i]['end'] = $now;
                $message = 'Work ended at ' . $now;
                break;
            }
        }
        if ($message === '') {
            $message = 'No open session to close.';
        }
    }

    file_put_contents($timeFile, json_encode($logs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// find todays entries for this employee
$today = date('Y-m-d');
$todayLogs = [];
$hasOpen = false;

foreach ($logs as $log) {
    if ($log['employee_id'] == $employeeId && $log['date'] === $today) {
        $todayLogs[] = $log;
        if ($log['end'] === null) {
            $hasOpen = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My work day - HSYNC</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<div class="main" style="max-width:800px;margin:24px auto 40px;">
    <section class="section">
        <h2>Hello, <?= htmlspecialchars($employeeName) ?></h2>
        <p style="font-size:13px;color:#9ca3af;">Use this page to start and end your work day.</p>

        <?php if ($message): ?>
            <p style="font-size:12px;color:#bbf7d0;"><?= htmlspecialchars($message) ?></p>
        <?php endif; ?>

        <form method="post" style="margin-top:10px;">
            <?php if ($hasOpen): ?>
                <button class="button" type="submit" name="action" value="end">End work now</button>
            <?php else: ?>
                <button class="button" type="submit" name="action" value="start">Start work now</button>
            <?php endif; ?>
        </form>
    </section>
<p style="font-size:13px;">
    <a href="chat.php">Open team chat</a>
</p>

    <section class="section" style="margin-top:20px;">
        <h2>Today log</h2>
        <?php if (empty($todayLogs)): ?>
            <p style="font-size:13px;">No work sessions logged today.</p>
        <?php else: ?>
            <table style="width:100%;border-collapse:collapse;font-size:13px;margin-top:10px;">
                <thead>
                <tr>
                    <th style="text-align:left;border-bottom:1px solid #111827;padding:6px 8px;">Start</th>
                    <th style="text-align:left;border-bottom:1px solid #111827;padding:6px 8px;">End</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($todayLogs as $log): ?>
                    <tr>
                        <td style="padding:6px 8px;"><?= htmlspecialchars($log['start']) ?></td>
                        <td style="padding:6px 8px;"><?= htmlspecialchars($log['end'] ?? 'Still working') ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </section>
</div>
</body>
</html>
