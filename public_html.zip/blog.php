<?php
$adminDataDir = __DIR__ . '/admin/data';

$blogPosts = [];
$seo = [];
$companyName = 'HSYNC Group';

// load company info if config exists
$configPath = __DIR__ . '/admin/config.php';
if (file_exists($configPath)) {
    require $configPath;
    if (!empty($COMPANY_NAME)) $companyName = $COMPANY_NAME;
}

// load blog posts
if (file_exists($adminDataDir . '/blog-posts.json')) {
    $postsJson = file_get_contents($adminDataDir . '/blog-posts.json');
    $blogPosts = json_decode($postsJson, true) ?: [];
}

// load seo
if (file_exists($adminDataDir . '/seo.json')) {
    $seoJson = file_get_contents($adminDataDir . '/seo.json');
    $seo = json_decode($seoJson, true) ?: [];
}

$blogTitle = $seo['blog']['title'] ?? "$companyName blog";
$blogDesc = $seo['blog']['description'] ?? '';

$blogPosts = array_reverse($blogPosts);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($blogTitle) ?></title>
    <meta name="description" content="<?= htmlspecialchars($blogDesc) ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header class="header">
    <div class="header-inner">
        <div class="logo"><?= htmlspecialchars($companyName) ?></div>
        <nav class="nav">
            <a href="/">Home</a>
            <a href="/blog.php">Blog</a>
            <a href="/admin/login.php">Admin</a>
        </nav>
    </div>
</header>

<main class="main">
    <section class="section">
        <h2>HSYNC blog and news</h2>
        <p style="font-size:14px;color:#9ca3af;"><?= htmlspecialchars($blogDesc) ?></p>

        <?php if (empty($blogPosts)): ?>
            <p>No posts published yet.</p>
        <?php else: ?>
            <?php foreach ($blogPosts as $post): ?>
                <article class="blog-list-item">
                    <div class="blog-title"><?= htmlspecialchars($post['title']) ?></div>
                    <div class="blog-meta"><?= htmlspecialchars($post['date'] ?? '') ?></div>
                    <div style="font-size:14px;color:#e5e7eb;margin-top:4px;white-space:pre-wrap;">
                        <?= nl2br(htmlspecialchars($post['content'] ?? '')) ?>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</main>

<footer class="footer">
    © <?= date('Y') ?> <?= htmlspecialchars($companyName) ?>. All rights reserved.
</footer>
</body>
</html>
