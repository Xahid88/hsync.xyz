<?php
require_once 'config.php';

if (empty($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    header('Location: login.php');
    exit;
}

$msgFile = __DIR__ . '/data/messages.json';
$onlineFile = __DIR__ . '/data/online.json';
$empFile = __DIR__ . '/data/employees.json';

$messages = [];
$online = [];
$employees = [];

// load employees
if (file_exists($empFile)) {
    $json = file_get_contents($empFile);
    $employees = json_decode($json, true) ?: [];
}

// load messages
if (file_exists($msgFile)) {
    $json = file_get_contents($msgFile);
    $messages = json_decode($json, true) ?: [];
}

// load online list
if (file_exists($onlineFile)) {
    $json = file_get_contents($onlineFile);
    $online = json_decode($json, true) ?: [];
}

// update current admin last seen
$now = time();
$adminId = 0;
$adminName = $_SESSION['admin_email'] ?? 'Admin';

$found = false;
foreach ($online as &$o) {
    if ($o['role'] === 'admin' && (int) $o['id'] === $adminId) {
        $o['name'] = $adminName;
        $o['last_seen'] = $now;
        $found = true;
        break;
    }
}
unset($o);

if (!$found) {
    $online[] = [
        'role' => 'admin',
        'id' => $adminId,
        'name' => $adminName,
        'last_seen' => $now
    ];
}

// keep only last 200 entries to avoid file growing forever
if (count($online) > 200) {
    $online = array_slice($online, -200);
}

file_put_contents($onlineFile, json_encode($online, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

// view mode: team or direct
$mode = $_GET['mode'] ?? 'team';
$toId = isset($_GET['to']) ? (int) $_GET['to'] : 0;

// handle send
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $text = trim($_POST['message'] ?? '');
    $targetMode = $_POST['mode'] ?? 'team';
    $targetTo = isset($_POST['to_id']) ? (int) $_POST['to_id'] : 0;

    if ($text !== '') {
        $msg = [
            'type' => $targetMode === 'direct' ? 'direct' : 'team',
            'from_role' => 'admin',
            'from_id' => $adminId,
            'from_name' => $adminName,
            'time' => date('Y-m-d H:i:s'),
            'text' => $text
        ];
        if ($msg['type'] === 'direct') {
            $msg['to_id'] = $targetTo;
        }
        $messages[] = $msg;
        file_put_contents($msgFile, json_encode($messages, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        if ($targetMode === 'direct' && $targetTo > 0) {
            header('Location: chat.php?mode=direct&to=' . $targetTo);
        } else {
            header('Location: chat.php?mode=team');
        }
        exit;
    }
}

// filter messages to display
$viewMessages = [];
if ($mode === 'direct' && $toId > 0) {
    foreach ($messages as $m) {
        if (($m['type'] ?? 'team') !== 'direct') {
            continue;
        }
        $fid = $m['from_id'] ?? null;
        $tid = $m['to_id'] ?? null;
        // conversation between admin (0) and employee $toId
        if (
            ($fid === 0 && $tid === $toId) ||
            ($fid === $toId && $tid === 0)
        ) {
            $viewMessages[] = $m;
        }
    }
} else {
    foreach ($messages as $m) {
        if (($m['type'] ?? 'team') === 'direct') {
            continue;
        }
        $viewMessages[] = $m;
    }
}

// limit to last 80
$viewMessages = array_slice($viewMessages, -80);

// simple notification: count of messages in current view
$unreadCount = count($viewMessages);

// helper to check online state
function is_online($online, $role, $id) {
    $now = time();
    foreach ($online as $o) {
        if ($o['role'] === $role && (int) $o['id'] === (int) $id) {
            if ($now - (int) $o['last_seen'] <= 120) { // 2 minutes
                return true;
            }
        }
    }
    return false;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Team chat - HSYNC admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/assets/style.css">
</head>
<script>
    // Auto refresh chat every 10 seconds
    var refreshSeconds = 10;
    setTimeout(function () {
        window.location.reload();
    }, refreshSeconds * 1000);

    // Scroll chat box to bottom on load
    window.addEventListener("load", function () {
        var box = document.getElementById("chat-box");
        if (box) {
            box.scrollTop = box.scrollHeight;
        }
    });
</script>
<body>
<div class="main" style="max-width:1000px;margin:24px auto 40px;display:flex;gap:16px;">
    <div style="width:240px;">
        <section class="section">
            <h2 style="font-size:16px;margin-bottom:8px;">People</h2>
            <p style="font-size:12px;color:#9ca3af;">Online status updates while chat page is open.</p>

            <div style="margin-top:8px;font-size:13px;">
                <div style="margin-bottom:6px;">
                    <strong>Admin (you)</strong>
                    <span style="font-size:11px;color:#22c55e;">● online</span>
                </div>
                <div style="margin-top:6px;font-size:12px;color:#9ca3af;">Employees</div>
                <?php if (empty($employees)): ?>
                    <p style="font-size:12px;">No employees.</p>
                <?php else: ?>
                    <?php foreach ($employees as $emp): ?>
                        <?php
                        $onlineFlag = is_online($online, 'employee', $emp['id']);
                        $link = 'chat.php?mode=direct&to=' . $emp['id'];
                        ?>
                        <div style="margin-top:4px;">
                            <a href="<?= htmlspecialchars($link) ?>" style="font-size:13px;">
                                <?= htmlspecialchars($emp['name']) ?>
                                <?php if (!empty($emp['designation'])): ?>
                                    <span style="font-size:11px;color:#6b7280;">(<?= htmlspecialchars($emp['designation']) ?>)</span>
                                <?php endif; ?>
                            </a>
                            <?php if ($onlineFlag): ?>
                                <span style="font-size:11px;color:#22c55e;">● online</span>
                            <?php else: ?>
                                <span style="font-size:11px;color:#6b7280;">● offline</span>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </section>
    </div>

    <div style="flex:1;">
        <section class="section">
            <h2 style="font-size:16px;margin-bottom:6px;">
                <?php if ($mode === 'direct' && $toId > 0): ?>
                    Direct chat
                <?php else: ?>
                    Team room
                <?php endif; ?>
            </h2>
            <p style="font-size:12px;color:#9ca3af;">
                <a href="chat.php?mode=team" style="margin-right:10px;">Team room</a>
                |
                <span style="margin-left:10px;">Direct chat: click an employee name on the left.</span>
            </p>
            <p style="font-size:12px;color:#93c5fd;margin-top:4px;">
                Messages in this view: <?= (int) $unreadCount ?>
            </p>

           <div id="chat-box" style="max-height:420px;overflow-y:auto;border:1px solid #111827;border-radius:10px;padding:10px;margin-top:10px;background:#020617;">
                <?php if (empty($viewMessages)): ?>
                    <p style="font-size:13px;color:#6b7280;">No messages yet.</p>
                <?php else: ?>
                    <?php foreach ($viewMessages as $m): ?>
                        <div style="margin-bottom:8px;">
                            <div style="font-size:12px;color:#9ca3af;">
                                <strong><?= htmlspecialchars($m['from_name'] ?? 'User') ?></strong>
                                <span style="color:#6b7280;">(<?= htmlspecialchars($m['from_role'] ?? '') ?>)</span>
                                <span style="float:right;color:#4b5563;"><?= htmlspecialchars($m['time'] ?? '') ?></span>
                            </div>
                            <div style="font-size:14px;color:#e5e7eb;white-space:pre-wrap;">
                                <?= nl2br(htmlspecialchars($m['text'] ?? '')) ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <form method="post" style="margin-top:12px;">
                <input type="hidden" name="mode" value="<?= $mode === 'direct' && $toId > 0 ? 'direct' : 'team' ?>">
                <input type="hidden" name="to_id" value="<?= $toId ?>">
                <div class="form-field">
                    <label for="message">Send message</label>
                    <textarea id="message" name="message"></textarea>
                </div>
                <button class="button" type="submit">Send</button>
            </form>
        </section>
    </div>
</div>
</body>
</html>
