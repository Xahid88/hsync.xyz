<?php
require_once 'config.php';

if (empty($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    header('Location: login.php');
    exit;
}

$dataFile = __DIR__ . '/data/blog-posts.json';
$posts = [];

if (file_exists($dataFile)) {
    $json = file_get_contents($dataFile);
    $posts = json_decode($json, true) ?: [];
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');

    if ($title === '' || $content === '') {
        $message = 'Title and content are required.';
    } else {
        $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $title));
        $slug = trim($slug, '-');

        $posts[] = [
            'title' => $title,
            'slug' => $slug,
            'date' => date('Y-m-d'),
            'content' => $content
        ];

        file_put_contents($dataFile, json_encode($posts, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $message = 'Post created.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>New blog post</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<div class="main" style="max-width:800px;margin:24px auto 40px;">
    <a href="dashboard.php" style="font-size:12px;color:#93c5fd;">← Back to dashboard</a>
    <section class="section">
        <h2>New blog post</h2>
        <p style="font-size:13px;color:#9ca3af;">Write a simple update or article.</p>

        <?php if ($message): ?>
            <p style="font-size:12px;color:<?= strpos($message, 'required') !== false ? '#fecaca' : '#bbf7d0' ?>;">
                <?= htmlspecialchars($message) ?>
            </p>
        <?php endif; ?>

        <form method="post">
            <div class="form-field">
                <label for="title">Title</label>
                <input id="title" type="text" name="title" required>
            </div>
            <div class="form-field">
                <label for="content">Content</label>
                <textarea id="content" name="content" required></textarea>
            </div>
            <button class="button" type="submit">Publish</button>
        </form>
    </section>
</div>
</body>
</html>
