<?php
require_once 'config.php';

if (empty($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    header('Location: login.php');
    exit;
}

$dataFile = __DIR__ . '/data/employees.json';
$employees = [];

if (file_exists($dataFile)) {
    $json = file_get_contents($dataFile);
    $employees = json_decode($json, true) ?: [];
}

// handle delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $deleteId = (int) $_POST['delete_id'];
    $employees = array_values(array_filter($employees, function ($emp) use ($deleteId) {
        return (int) $emp['id'] !== $deleteId;
    }));
    file_put_contents($dataFile, json_encode($employees, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    header('Location: employee-list.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employees - HSYNC admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<div class="main" style="max-width:900px;margin:24px auto 40px;">
    <a href="dashboard.php" style="font-size:12px;color:#93c5fd;">← Back to dashboard</a>
    <section class="section">
        <h2>Employees</h2>
        <p style="font-size:13px;color:#9ca3af;">Manage employee accounts for time tracking and chat.</p>

        <p><a href="employee-edit.php">+ Add new employee</a></p>

        <table style="width:100%;border-collapse:collapse;font-size:13px;margin-top:10px;">
            <thead>
            <tr>
                <th style="text-align:left;border-bottom:1px solid #111827;padding:6px 8px;">ID</th>
                <th style="text-align:left;border-bottom:1px solid #111827;padding:6px 8px;">Name</th>
                <th style="text-align:left;border-bottom:1px solid #111827;padding:6px 8px;">Email</th>
                <th style="text-align:left;border-bottom:1px solid #111827;padding:6px 8px;">Designation</th>
                <th style="text-align:left;border-bottom:1px solid #111827;padding:6px 8px;">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php if (empty($employees)): ?>
                <tr><td colspan="5" style="padding:6px 8px;">No employees yet.</td></tr>
            <?php else: ?>
                <?php foreach ($employees as $emp): ?>
                    <tr>
                        <td style="padding:6px 8px;"><?= htmlspecialchars($emp['id']) ?></td>
                        <td style="padding:6px 8px;"><?= htmlspecialchars($emp['name']) ?></td>
                        <td style="padding:6px 8px;"><?= htmlspecialchars($emp['email']) ?></td>
                        <td style="padding:6px 8px;"><?= htmlspecialchars($emp['designation'] ?? '') ?></td>
                        <td style="padding:6px 8px;">
                            <a href="employee-edit.php?id=<?= urlencode($emp['id']) ?>">Edit</a>
                            <form method="post" style="display:inline;margin-left:8px;" onsubmit="return confirm('Delete this employee?');">
                                <input type="hidden" name="delete_id" value="<?= htmlspecialchars($emp['id']) ?>">
                                <button type="submit" style="background:none;border:none;color:#fecaca;font-size:12px;cursor:pointer;">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </section>
</div>
</body>
</html>
