<?php
require_once 'config.php';

if (empty($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    header('Location: login.php');
    exit;
}

$adminEmail = $_SESSION['admin_email'] ?? 'Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HSYNC admin dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { margin:0;font-family:system-ui, -apple-system, BlinkMacSystemFont, sans-serif;background:#020617;color:#e5e7eb; }
        .shell { display:flex;min-height:100vh; }
        .sidebar { width:220px;background:#020617;border-right:1px solid #111827;padding:16px 10px;box-sizing:border-box; }
        .logo { display:flex;align-items:center;gap:8px;margin-bottom:16px;padding:0 6px; }
        .logo-mark { width:28px;height:28px;border-radius:999px;background:radial-gradient(circle at 20% 20%,#ec4899,transparent 60%),radial-gradient(circle at 80% 80%,#3b82f6,transparent 60%);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600; }
        .logo-text { font-size:14px;font-weight:600; }
        .nav-title { font-size:11px;text-transform:uppercase;letter-spacing:0.12em;color:#6b7280;margin:10px 6px 4px; }
        .nav-link { display:flex;align-items:center;gap:8px;padding:7px 8px;margin:2px 4px;border-radius:8px;font-size:13px;color:#9ca3af;text-decoration:none; }
        .nav-link:hover { background:#111827;color:#e5e7eb; }
        .main { flex:1;display:flex;flex-direction:column; }
        .topbar { display:flex;justify-content:space-between;align-items:center;padding:10px 16px;border-bottom:1px solid #111827;background:rgba(2,6,23,0.95);position:sticky;top:0;z-index:10; }
        .top-title { font-size:17px;margin:0; }
        .top-right { display:flex;align-items:center;gap:10px; }
        .top-view { font-size:12px;color:#93c5fd;text-decoration:none; }
        .top-view:hover { text-decoration:underline; }
        .user-pill { font-size:12px;color:#e5e7eb; }
        .logout-btn { border-radius:999px;border:1px solid #374151;background:#020617;color:#9ca3af;padding:4px 9px;font-size:11px;cursor:pointer; }
        .logout-btn:hover { background:#111827;color:#e5e7eb; }
        .content { padding:16px 18px 40px; }
        .grid { display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px; }
        .card { background:#020617;border-radius:14px;border:1px solid #111827;padding:12px; }
        .card-label { font-size:12px;color:#9ca3af; }
        .card-value { font-size:20px;font-weight:600;margin-top:3px; }
        .card-sub { font-size:11px;color:#6b7280;margin-top:4px; }
    </style>
</head>
<body>
<div class="shell">
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-mark">HS</div>
            <div class="logo-text">HSYNC admin</div>
        </div>
        <div class="nav-title">Main</div>
        <a class="nav-link" href="dashboard.php"><span>📊</span><span>Dashboard</span></a>
        <div class="nav-title">Content</div>
        <a class="nav-link" href="#"><span>🏠</span><span>Edit home (soon)</span></a>
        <a class="nav-link" href="#"><span>🔍</span><span>SEO editor (soon)</span></a>
        <a class="nav-link" href="#"><span>📰</span><span>Blog posts (soon)</span></a>
        <div class="nav-title">Employees</div>
        <a class="nav-link" href="employee-list.php"><span>👥</span><span>Manage employees</span></a>
        <a class="nav-link" href="#"><span>👤</span><span>Employee panel (soon)</span></a>
    </aside>

    <div class="main">
        <header class="topbar">
            <h1 class="top-title">HSYNC overview</h1>
            <div class="top-right">
                <a class="top-view" href="/" target="_blank">View site</a>
                <span class="user-pill"><?= htmlspecialchars($adminEmail) ?></span>
                <form action="logout.php" method="post" style="margin:0;">
                    <button type="submit" class="logout-btn">Sign out</button>
                </form>
            </div>
        </header>
        <main class="<div style="margin-top:20px;font-size:13px;">
    <p><strong>Quick actions</strong></p><a href="seo-edit.php">Edit SEO for home and blog</a><br>
<a href="blog-list.php">Manage blog posts</a><br>
<a href="blog-new.php">Write new post</a><br>
<a href="chat.php">Open team chat</a><br>

<a href="time-report.php">View work time report</a><br>

    <p>
        <a href="edit-home.php">Edit home page content</a>
    </p>
</div>
">
            <div class="grid">
                <div class="card">
                    <div class="card-label">Website</div>
                    <div class="card-value">Online</div>
                    <div class="card-sub">Public site is running at your domain.</div>
                </div>
                <div class="card">
                    <div class="card-label">Admin</div>
                    <div class="card-value">Active</div>
                    <div class="card-sub">You are logged in as administrator.</div>
                </div>
            </div>
        </main>
    </div>
</div>
</body>
</html>
