<?php
require_once 'config.php';

if (empty($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    header('Location: login.php');
    exit;
}

$dataFile = __DIR__ . '/data/employees.json';
$employees = [];

if (file_exists($dataFile)) {
    $json = file_get_contents($dataFile);
    $employees = json_decode($json, true) ?: [];
}

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$editing = $id > 0;

$name = '';
$email = '';
$password = '';
$designation = '';
$message = '';

if ($editing) {
    foreach ($employees as $emp) {
        if ((int) $emp['id'] === $id) {
            $name = $emp['name'] ?? '';
            $email = $emp['email'] ?? '';
            $password = $emp['password'] ?? '';
            $designation = $emp['designation'] ?? '';
            break;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $designation = trim($_POST['designation'] ?? '');

    if ($name === '' || $email === '' || $password === '') {
        $message = 'Name, email and password are required.';
    } else {
        if ($editing) {
            foreach ($employees as &$emp) {
                if ((int) $emp['id'] === $id) {
                    $emp['name'] = $name;
                    $emp['email'] = $email;
                    $emp['password'] = $password;
                    $emp['designation'] = $designation;
                    break;
                }
            }
            unset($emp);
        } else {
            $maxId = 0;
            foreach ($employees as $emp) {
                if ((int) $emp['id'] > $maxId) {
                    $maxId = (int) $emp['id'];
                }
            }
            $newId = $maxId + 1;
            $employees[] = [
                'id' => $newId,
                'name' => $name,
                'email' => $email,
                'password' => $password,
                'designation' => $designation
            ];
            $id = $newId;
            $editing = true;
        }

        file_put_contents($dataFile, json_encode($employees, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $message = 'Employee saved.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $editing ? 'Edit employee' : 'Add employee' ?> - HSYNC admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<div class="main" style="max-width:600px;margin:24px auto 40px;">
    <a href="employee-list.php" style="font-size:12px;color:#93c5fd;">← Back to employees</a>
    <section class="section">
        <h2><?= $editing ? 'Edit employee' : 'Add employee' ?></h2>

        <?php if ($message): ?>
            <p style="font-size:12px;color:#bbf7d0;"><?= htmlspecialchars($message) ?></p>
        <?php endif; ?>

        <form method="post">
            <div class="form-field">
                <label for="name">Name</label>
                <input id="name" type="text" name="name" value="<?= htmlspecialchars($name) ?>" required>
            </div>
            <div class="form-field">
                <label for="email">Email</label>
                <input id="email" type="email" name="email" value="<?= htmlspecialchars($email) ?>" required>
            </div>
            <div class="form-field">
                <label for="password">Password</label>
                <input id="password" type="text" name="password" value="<?= htmlspecialchars($password) ?>" required>
            </div>
            <div class="form-field">
                <label for="designation">Designation</label>
                <input id="designation" type="text" name="designation" value="<?= htmlspecialchars($designation) ?>">
            </div>
            <button class="button" type="submit">Save employee</button>
        </form>
    </section>
</div>
</body>
</html>
