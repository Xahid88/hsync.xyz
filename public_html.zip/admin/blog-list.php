<?php
require_once 'config.php';

if (empty($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    header('Location: login.php');
    exit;
}

$dataFile = __DIR__ . '/data/blog-posts.json';
$posts = [];

if (file_exists($dataFile)) {
    $json = file_get_contents($dataFile);
    $posts = json_decode($json, true) ?: [];
}

$posts = array_reverse($posts);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Blog posts</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<div class="main" style="max-width:800px;margin:24px auto 40px;">
    <a href="dashboard.php" style="font-size:12px;color:#93c5fd;">← Back to dashboard</a>
    <section class="section">
        <h2>Blog posts</h2>
        <p style="font-size:13px;color:#9ca3af;">Posts are stored in blog-posts.json.</p>
        <p><a href="blog-new.php">+ Write new post</a></p>

        <table style="width:100%;border-collapse:collapse;font-size:13px;margin-top:10px;">
            <thead>
            <tr>
                <th style="text-align:left;border-bottom:1px solid #111827;padding:6px 8px;">Title</th>
                <th style="text-align:left;border-bottom:1px solid #111827;padding:6px 8px;">Date</th>
                <th style="text-align:left;border-bottom:1px solid #111827;padding:6px 8px;">Slug</th>
            </tr>
            </thead>
            <tbody>
            <?php if (empty($posts)): ?>
                <tr><td colspan="3" style="padding:6px 8px;">No posts yet.</td></tr>
            <?php else: ?>
                <?php foreach ($posts as $post): ?>
                    <tr>
                        <td style="padding:6px 8px;"><?= htmlspecialchars($post['title']) ?></td>
                        <td style="padding:6px 8px;"><?= htmlspecialchars($post['date'] ?? '') ?></td>
                        <td style="padding:6px 8px;"><?= htmlspecialchars($post['slug'] ?? '') ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </section>
</div>
</body>
</html>
