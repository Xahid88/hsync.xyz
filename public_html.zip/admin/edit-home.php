<?php
require_once 'config.php';

if (empty($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    header('Location: login.php');
    exit;
}

$dataFile = __DIR__ . '/data/site-content.json';

$homeHeading = '';
$homeSubtitle = '';
$aboutText = '';
$servicesText = '';
$contactText = '';
$message = '';

// load existing values
if (file_exists($dataFile)) {
    $json = file_get_contents($dataFile);
    $data = json_decode($json, true) ?: [];
    $homeHeading = $data['home_heading'] ?? '';
    $homeSubtitle = $data['home_subtitle'] ?? '';
    $aboutText = $data['about_text'] ?? '';
    $servicesText = $data['services_text'] ?? '';
    $contactText = $data['contact_text'] ?? '';
}

// handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $homeHeading = trim($_POST['home_heading'] ?? '');
    $homeSubtitle = trim($_POST['home_subtitle'] ?? '');
    $aboutText = trim($_POST['about_text'] ?? '');
    $servicesText = trim($_POST['services_text'] ?? '');
    $contactText = trim($_POST['contact_text'] ?? '');

    $newData = [
        'home_heading' => $homeHeading,
        'home_subtitle' => $homeSubtitle,
        'about_text' => $aboutText,
        'services_text' => $servicesText,
        'contact_text' => $contactText,
    ];

    file_put_contents($dataFile, json_encode($newData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    $message = 'Home content updated.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit home content</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<div class="main" style="max-width:800px;margin:24px auto 40px;">
    <a href="dashboard.php" style="font-size:12px;color:#93c5fd;">← Back to dashboard</a>
    <section class="section">
        <h2>Edit home page content</h2>
        <?php if ($message): ?>
            <p style="font-size:12px;color:#bbf7d0;"><?= htmlspecialchars($message) ?></p>
        <?php endif; ?>

        <form method="post">
            <div class="form-field">
                <label for="home_heading">Main heading</label>
                <input id="home_heading" type="text" name="home_heading" value="<?= htmlspecialchars($homeHeading) ?>">
            </div>

            <div class="form-field">
                <label for="home_subtitle">Subtitle</label>
                <textarea id="home_subtitle" name="home_subtitle"><?= htmlspecialchars($homeSubtitle) ?></textarea>
            </div>

            <div class="form-field">
                <label for="about_text">About section text</label>
                <textarea id="about_text" name="about_text"><?= htmlspecialchars($aboutText) ?></textarea>
            </div>

            <div class="form-field">
                <label for="services_text">Services section text</label>
                <textarea id="services_text" name="services_text"><?= htmlspecialchars($servicesText) ?></textarea>
            </div>

            <div class="form-field">
                <label for="contact_text">Contact section text</label>
                <textarea id="contact_text" name="contact_text"><?= htmlspecialchars($contactText) ?></textarea>
            </div>

            <button class="button" type="submit">Save changes</button>
        </form>
    </section>
</div>
</body>
</html>
