<?php
require_once 'config.php';

if (empty($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    header('Location: login.php');
    exit;
}

$dataFile = __DIR__ . '/data/seo.json';

$seo = [
    'home' => ['title' => '', 'description' => ''],
    'blog' => ['title' => '', 'description' => ''],
];

if (file_exists($dataFile)) {
    $json = file_get_contents($dataFile);
    $current = json_decode($json, true) ?: [];
    $seo = array_merge($seo, $current);
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $seo['home']['title'] = trim($_POST['home_title'] ?? '');
    $seo['home']['description'] = trim($_POST['home_desc'] ?? '');
    $seo['blog']['title'] = trim($_POST['blog_title'] ?? '');
    $seo['blog']['description'] = trim($_POST['blog_desc'] ?? '');

    file_put_contents($dataFile, json_encode($seo, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    $message = 'SEO settings saved.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SEO editor</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<div class="main" style="max-width:800px;margin:24px auto 40px;">
    <a href="dashboard.php" style="font-size:12px;color:#93c5fd;">← Back to dashboard</a>
    <section class="section">
        <h2>SEO editor</h2>
        <p style="font-size:13px;color:#9ca3af;">Control page titles and descriptions for better search ranking.</p>

        <?php if ($message): ?>
            <p style="font-size:12px;color:#bbf7d0;"><?= htmlspecialchars($message) ?></p>
        <?php endif; ?>

        <form method="post">
            <h3 style="font-size:15px;margin-top:10px;">Home page</h3>
            <div class="form-field">
                <label for="home_title">Home title</label>
                <input id="home_title" type="text" name="home_title" value="<?= htmlspecialchars($seo['home']['title'] ?? '') ?>">
            </div>
            <div class="form-field">
                <label for="home_desc">Home description</label>
                <textarea id="home_desc" name="home_desc"><?= htmlspecialchars($seo['home']['description'] ?? '') ?></textarea>
            </div>

            <h3 style="font-size:15px;margin-top:16px;">Blog page</h3>
            <div class="form-field">
                <label for="blog_title">Blog title</label>
                <input id="blog_title" type="text" name="blog_title" value="<?= htmlspecialchars($seo['blog']['title'] ?? '') ?>">
            </div>
            <div class="form-field">
                <label for="blog_desc">Blog description</label>
                <textarea id="blog_desc" name="blog_desc"><?= htmlspecialchars($seo['blog']['description'] ?? '') ?></textarea>
            </div>

            <button class="button" type="submit">Save SEO</button>
        </form>
    </section>
</div>
</body>
</html>
