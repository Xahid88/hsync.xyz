<?php
require_once 'config.php';

// If already logged in, go to dashboard
if (!empty($_SESSION['admin_logged']) && $_SESSION['admin_logged'] === true) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($email === $ADMIN_EMAIL && $password === $ADMIN_PASSWORD) {
        $_SESSION['admin_logged'] = true;
        $_SESSION['admin_email'] = $email;
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Wrong email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HSYNC admin login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            margin: 0;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
            background: #020617;
            color: #e5e7eb;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        .card {
            background: #020617;
            border-radius: 16px;
            border: 1px solid #111827;
            padding: 20px 22px;
            width: 320px;
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.9);
        }
        h1 {
            margin: 0 0 10px;
            font-size: 18px;
        }
        p {
            margin: 0 0 10px;
            font-size: 13px;
            color: #9ca3af;
        }
        .field {
            margin-bottom: 10px;
        }
        label {
            display: block;
            font-size: 12px;
            margin-bottom: 3px;
            color: #9ca3af;
        }
        input {
            width: 100%;
            padding: 8px 10px;
            border-radius: 10px;
            border: 1px solid #374151;
            background: #020617;
            color: #e5e7eb;
            font-size: 13px;
            box-sizing: border-box;
        }
        input:focus {
            border-color: #3b82f6;
            outline: none;
        }
        .btn {
            width: 100%;
            padding: 8px 10px;
            border-radius: 999px;
            border: 1px solid #2563eb;
            background: #2563eb;
            color: white;
            font-size: 13px;
            margin-top: 6px;
            cursor: pointer;
        }
        .error {
            font-size: 12px;
            color: #fecaca;
            background: rgba(220, 38, 38, 0.15);
            border-radius: 10px;
            border: 1px solid #ef4444;
            padding: 6px 8px;
            margin-bottom: 8px;
        }
        .hint {
            font-size: 11px;
            color: #6b7280;
            margin-top: 8px;
            text-align: center;
        }
    </style>
</head>
<body>
<div class="card">
    <h1>HSYNC admin</h1>
    <p>Sign in to manage your site.</p>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post">
        <div class="field">
            <label for="email">Admin email</label>
            <input id="email" type="email" name="email" required>
        </div>
        <div class="field">
            <label for="password">Password</label>
            <input id="password" type="password" name="password" required>
        </div>
        <button class="btn" type="submit">Sign in</button>
    </form>

    <div class="hint">
        Change email and password in admin/config.php.
    </div>
</div>
</body>
</html>
