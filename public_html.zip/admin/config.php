<?php
// Start session for admin
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Admin login information
$ADMIN_EMAIL = 'admin@hsync.xyz';        // change to your email
$ADMIN_PASSWORD = 'ChangeThisStrong123'; // change to a strong password

// Company information for use in backend if needed
$COMPANY_NAME = 'HSYNC Group';
$COMPANY_WEBSITE = 'https://hsync.xyz';
$COMPANY_EMAIL = 'info@hsync.xyz';
$COMPANY_ADDRESS = 'Los Angeles, California, USA';
