<?php
require_once 'config.php';

if (empty($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    header('Location: login.php');
    exit;
}

$empFile = __DIR__ . '/data/employees.json';
$timeFile = __DIR__ . '/data/time-logs.json';

$employees = [];
$logs = [];

if (file_exists($empFile)) {
    $json = file_get_contents($empFile);
    $employees = json_decode($json, true) ?: [];
}

if (file_exists($timeFile)) {
    $json = file_get_contents($timeFile);
    $logs = json_decode($json, true) ?: [];
}

// map employee id to name
$empMap = [];
foreach ($employees as $emp) {
    $empMap[$emp['id']] = [
        'name' => $emp['name'],
        'designation' => $emp['designation'] ?? ''
    ];
}

// sum time per employee (all time)
$totals = [];
foreach ($logs as $log) {
    $empId = $log['employee_id'];
    if (!isset($totals[$empId])) {
        $totals[$empId] = 0;
    }
    if (!empty($log['start'])) {
        $start = strtotime($log['start']);
        $end = !empty($log['end']) ? strtotime($log['end']) : time();
        if ($end > $start) {
            $totals[$empId] += ($end - $start);
        }
    }
}

// find max seconds for chart scale
$maxSeconds = 0;
foreach ($totals as $sec) {
    if ($sec > $maxSeconds) {
        $maxSeconds = $sec;
    }
}

function formatHours($seconds) {
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    return $hours . 'h ' . $minutes . 'm';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Work report - HSYNC admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<div class="main" style="max-width:900px;margin:24px auto 40px;">
    <a href="dashboard.php" style="font-size:12px;color:#93c5fd;">← Back to dashboard</a>
    <section class="section">
        <h2>Work report</h2>
        <p style="font-size:13px;color:#9ca3af;">Total tracked time per employee (all time).</p>

        <?php if (empty($totals)): ?>
            <p>No time logs yet.</p>
        <?php else: ?>
            <table style="width:100%;border-collapse:collapse;font-size:13px;margin-top:10px;">
                <thead>
                <tr>
                    <th style="text-align:left;border-bottom:1px solid #111827;padding:6px 8px;">Employee</th>
                    <th style="text-align:left;border-bottom:1px solid #111827;padding:6px 8px;">Designation</th>
                    <th style="text-align:left;border-bottom:1px solid #111827;padding:6px 8px;">Total time</th>
                    <th style="text-align:left;border-bottom:1px solid #111827;padding:6px 8px;">Chart</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($totals as $empId => $seconds): ?>
                    <?php
                    $info = $empMap[$empId] ?? ['name' => 'Unknown', 'designation' => ''];
                    $percent = $maxSeconds > 0 ? round(($seconds / $maxSeconds) * 100) : 0;
                    if ($percent < 5) {
                        $percent = 5;
                    }
                    ?>
                    <tr>
                        <td style="padding:6px 8px;"><?= htmlspecialchars($info['name']) ?></td>
                        <td style="padding:6px 8px;"><?= htmlspecialchars($info['designation']) ?></td>
                        <td style="padding:6px 8px;"><?= htmlspecialchars(formatHours($seconds)) ?></td>
                        <td style="padding:6px 8px;">
                            <div style="background:#111827;border-radius:999px;overflow:hidden;height:12px;max-width:240px;">
                                <div style="height:12px;width:<?= $percent ?>%;background:#2563eb;"></div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </section>
</div>
</body>
</html>
